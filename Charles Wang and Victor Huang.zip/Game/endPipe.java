import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * End Pipe. Also the destination the character needs to reach to beat the game
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class endPipe extends Actor
{
    /**
     * Act - do whatever the endPipe wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
