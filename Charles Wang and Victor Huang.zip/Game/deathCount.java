import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Label for the death count. Displays the death count onto the screen in game
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class deathCount extends Actor
{
    /**
     * Act - do whatever the deathCount wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
