import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Actor for the top spike 
 * 
 * @author Charles Wang and Victor Huang 
 * @version June 2017
 */
public class topSpike extends Actor
{
    /**
     * Act - do whatever the upSpike wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
