import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The white background object to prevent player from seeing map (excludes the pipes and character)
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class whiteBackground extends Actor
{
    /**
     * Act - do whatever the whiteBackground wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
