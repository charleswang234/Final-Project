import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Level 7 for This is the Only Level Reboot
 * 
 * @author Charles Wang
 * @version June 2017
 */
public class levelSeven extends ZeeWeeld
{

    /**
     * Constructor for objects of class levelSeven.
     * 
     */
     public levelSeven()
    {    
        super(7); 
        prepare();
    }
}
