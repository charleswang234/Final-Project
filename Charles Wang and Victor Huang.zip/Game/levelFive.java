import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Level 5 for This is the Only Level Reboot
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class levelFive extends ZeeWeeld
{
    /**
     * Constructor for objects of class levelFive.
     * 
     */
    public levelFive()
    {
        super(5);
        prepare();
    }
}