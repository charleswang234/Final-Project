import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Image allowed for mouse click to restart the stage
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class panicButton extends Actor
{
    /**
     * Act - do whatever the panicButton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
    }
}
