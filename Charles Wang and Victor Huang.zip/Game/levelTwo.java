import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Level 2 for This is the Only Level Reboot
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class levelTwo extends ZeeWeeld
{
    /**
     * Constructor for objects of class levelTwo.
     * 
     */
    public levelTwo()
    {
        super(2);
        prepare();
    }
}