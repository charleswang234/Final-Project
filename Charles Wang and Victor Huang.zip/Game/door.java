import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Actor class for the door, which is needed to remove to complete each level of This is the Only Level Reboot
 * 
 * @author Charles Wag and Victor Huang
 * @version June 2017
 */
public class door extends Actor
{
    /**
     * Act - do whatever the door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
