import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Level 3 for This is the Only Level Reboot
 * 
 * @author Charles Wang and Victor Huang
 * @version June 2017
 */
public class levelThree extends ZeeWeeld
{
    /**
     * Constructor for objects of class levelTwo.
     * 
     */
    public levelThree()
    {
        super(3);
        prepare();
    }
}